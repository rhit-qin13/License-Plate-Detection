# License Plate Detection > 2024-01-24 6:31pm
https://universe.roboflow.com/cj-santos-e0nrn/license-plate-detection-3lgox

Provided by a Roboflow user
License: CC BY 4.0

